<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("db.sandbox.xellarant.com","Xellarant","techn0pathy","showme_staging") or die ("could not connect database");
 ?>