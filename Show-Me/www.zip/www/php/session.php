<?php
echo json_encode($_SESSION);
?>